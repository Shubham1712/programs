package com.reversestrings;

import java.io.Serializable;

public class ReverseString implements Serializable{
	
	public static void main(String[] args) {
		
		String str = "Shubham";
		String reverse = "";
		
		if(str!=null) {
			for (int i = str.length()-1 ; i>=0; i--) {
				reverse = reverse + str.charAt(i);
			}
		}
		
		System.out.println("String - "+str);
		System.out.println("Reverse - "+reverse);
	}
}
