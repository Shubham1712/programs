package com.set;

import java.util.HashSet;
import java.util.Set;


public class SetImpl {

	public static void main(String[] args) {
		
		Set<Employee> empSet = new HashSet<>();
		empSet.add(new Employee(1, "Shubham", "Pune"));
		empSet.add(new Employee(2, "Shubham", "Pune"));
		
		System.out.println("Size - "+empSet.size());
		System.out.println("Set -"+empSet);
	}
}
