package com.comparable.comparator;

import java.util.Comparator;


public class Order implements Comparable<Order>{
	
	private int orderId;
	private int price;
	private String customer;
	private String city;
	
	
	public Order() {
		super();
	}

	public Order(int orderId, int price, String customer, String city) {
		super();
		this.orderId = orderId;
		this.price = price;
		this.customer = customer;
		this.city = city;
	}

	@Override
	public int compareTo(Order o) {
		if(this.orderId > o.orderId) {
			return 1;
		}
		return this.orderId < o.orderId ? -1 : 0;
	}
	
	public static class OrderByAmount implements Comparator<Order>{

		@Override
		public int compare(Order o1, Order o2) {
			if(o1.price > o2.price) {
				return 1;
			}
			return o1.price < o2.price ? -1 : 0;
		}
	}
	
	public static class OrderByCustomer implements Comparator<Order>{

		@Override
		public int compare(Order o1, Order o2) {
			return o1.customer.compareTo(o2.customer);
		}
		
	}
	
	Comparator<Order> comp = ((Order o1, Order o2) -> {
			if(o1.price > o2.price) {
				return 1;
			}
			return o1.price < o2.price ? -1 : 0;
	});
	

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", price=" + price + ", customer=" + customer + ", city=" + city + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + orderId;
		result = prime * result + price;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (orderId != other.orderId)
			return false;
		if (price != other.price)
			return false;
		return true;
	}
	
}
