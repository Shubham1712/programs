package com.comparable.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.comparable.comparator.Order.OrderByCustomer;

public class ObjectSortingExample {

	public static void main(String[] args){
		
		Order order1 = new Order(1, 101, "Sony", "Pune");
		Order order2 = new Order(3, 202, "AA", "Amt");
		Order order3 = new Order(2, 150, "Micromax", "Akola");
		Order order4 = new Order(4, 144, "AA", "Buldana");
		
		List<Order> orderList = new ArrayList<>();
		orderList.add(order1);
		orderList.add(order4);
		orderList.add(order3);
		orderList.add(order2);
		
		System.out.println("\nOriginal List - ");
		orderList.forEach(System.out::println);
		
		Collections.sort(orderList);
		System.out.println("\nSorted List naturally: ");
		orderList.forEach(System.out::println);
		
		Collections.sort(orderList, Collections.reverseOrder());
		System.out.println("\nReveresed List - ");
		orderList.forEach(System.out::println);
				
		Collections.sort(orderList, new Order.OrderByAmount());
		System.out.println("\nSorted List by amount: ");
		orderList.forEach(System.out::println);
		
		Collections.sort(orderList, new Order.OrderByCustomer());
		System.out.println("\nSorted List by customer: ");
		orderList.forEach(System.out::println);
		
		System.out.println("---------------------------------------------------------");
		
		orderList.sort((Order o1, Order o2) -> o1.getCity().compareTo(o2.getCity()));
		System.out.println("\nSorted by City Comparator : ");
		orderList.forEach(System.out::println);
		
		orderList.sort((Order o1, Order o2) -> o1.getCustomer().compareTo(o2.getCustomer()));
		System.out.println("\nSorted by Customer Comparator : ");
		orderList.forEach(System.out::println);
		
		Collections.sort(orderList, new Order().comp); 
		System.out.println("\nSorted by Price Comparator : ");
		orderList.forEach(System.out::println);
		
	}

}
