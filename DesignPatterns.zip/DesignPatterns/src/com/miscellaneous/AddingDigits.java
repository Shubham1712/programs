package com.miscellaneous;

public class AddingDigits {
	
	public static void main(String[] args) {
		
		Long result = getNumber(2,12,17);			//12 11 1==121		//260 150 10=-1
		System.out.println("Result - "+result);
	}

	private static long getNumber(long a, long b, long n) {
		
		long c=0;
		if(a>0) {
			for (int i = 1; i <= n; i++) {
				for (int j = 0; j < 10; j++) {
					if((a*10+j)%b==0) {	//&& a%10!=j
						a=a*10+j;
						c=0;
						break;
					}
					else
						c=-1;
				}
				if(c==-1) {
					a=c;
					break;
				}
			}
		}
		return a;
	}
}

