package com.miscellaneous;

import java.util.Scanner;

public class ExcelColumn {

	public static void main(String[] args) {
		while(true) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter column in string(-1 to quiet):");
		String str = sc.next();
		if(str.equals("-1")) {
			break;
		}
		char[] charr = str.toCharArray();
		int i = 0;
		int tw_six_pow = 1;
		
		for (int j = charr.length-1; j > -1 ; j--) {
			i = i + (charr[j] - 'A' + 1)*tw_six_pow;
			tw_six_pow = tw_six_pow * 26;
		}
		System.out.println(i);
		}
	}
	
}
