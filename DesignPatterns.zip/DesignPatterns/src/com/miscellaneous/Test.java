package com.miscellaneous;

public class Test {

    public static void main(String[] args) {

        String html = "<html>\n" +
                      "   <body>\n" +
                      "      <p>Hello, World</p>\n" +
                      "   </body>\n" +
                      "</html>\n";

        @SuppressWarnings("preview")
		String java13 = """
                        <html>
                            <body>
                                <p>Hello, World</p>
                                <p>Hello Java 13</p>
                            </body>
                        </html>
                        """;

        @SuppressWarnings("preview")
		String java14 = """
                        <html>
                            <body>
                                <p>Hello,\sWorld</p>
                            </body>
                        </html>
                        """;

        System.out.println(html);
        System.out.println(java13);
        System.out.println(java14);

    }

}