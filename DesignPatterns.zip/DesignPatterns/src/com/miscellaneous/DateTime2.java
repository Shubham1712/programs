package com.miscellaneous;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;

public class DateTime2 {

private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	public static void main(String[] args) throws ParseException {
		
		DateTime2 t = new DateTime2();
		
		System.out.println("Double.MIN_VALUE - "+Double.MIN_VALUE);
		System.out.println(Math.min(Double.MIN_VALUE, 0.0d));
		
		System.out.println("StringFormat - "+String.format("%05d", 546));
		
		String abd = " sdhfi ";
		System.out.println("BeforeTrim -"+abd+"Aftertrim -"+abd.trim());
		
		t.call();
		
		System.out.println("DateTime - "+LocalDate.now());
		System.out.println("DateTime - "+Date.from(LocalDate.now().plusDays(45).atStartOfDay(ZoneId.systemDefault()).toInstant()));
		
	}

	private void call() throws ParseException {
		Date date = new Date();
		System.out.println("Date - "+date);
		String date1 = dateFormat.format(date);
		System.out.println("Date1 - "+date1+" String");
		Date date2 = dateFormat.parse(date1);
		System.out.println("Date2 - "+date2);
		
		int a = 1234708;
		Integer arr[] = {4,6,76,45,3,5,66,23,3};
		
		System.out.println("Reverse - "+reverseNo(a));
		System.out.println("Factorial - "+factorial(5));
		System.out.println("Factorial1 - "+factorial1(5));
		System.out.println("Original array - "+Arrays.toString(arr));
		System.out.println("Reverse array - "+reverseArray(arr));
		System.out.println("Instant - "+Instant.now());
		
	}

	private String reverseArray(Integer[] arr) {
		int temp;
		if(arr.length > 0) {
			for (int i = 0; i < arr.length/2; i++) {
				temp = arr[i];
				arr[i] = arr[arr.length - i - 1];
				arr[arr.length - i - 1] = temp;
			}
		}
		return Arrays.toString(arr);
	}

	private Integer factorial1(int i) {
		int result=1;
		while(i > 0) {
			result = result * i;
			i--;
		}
		return result;
	}

	private Integer factorial(int i) {
		if(i==0 || i==1)
			return 1;
		else
			return i*factorial(i-1);
	}

	private int reverseNo(int a) {
		int temp;
		int rev = 0;
		
		do {
			temp = a%10;				//1234%10 = 4
			rev = rev * 10 + temp;		//0*10 + 4
			a = a/10;
		} while (a>0);
		
		
		return rev;
	}
}
