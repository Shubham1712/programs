package com.miscellaneous;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
	
	public static void main(String[] args) {
		System.out.println("Enter 1st string : ");
		Scanner scan = new Scanner(System.in);
		String first = scan.next();
		System.out.println("Enter 2nd string : ");
		String second = scan.next();
		
		if(first.length() == second.length()) {
			
			if(findAnagrams(first,second))
				System.out.println("Angram");
			else
				System.out.println("Not Anagram");
		}else
			System.out.println("Length is different");
	}

	private static boolean findAnagrams(String first, String second) {

		Boolean bool = false;
		
		char[] fir = first.toLowerCase().toCharArray();
		char[] sec = second.toLowerCase().toCharArray();
		Arrays.sort(fir);
		Arrays.sort(sec);
		bool = Arrays.equals(fir, sec);
		
		return bool;
	}
}
