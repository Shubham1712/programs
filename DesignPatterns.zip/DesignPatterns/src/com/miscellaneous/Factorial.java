package com.miscellaneous;

public class Factorial {
	
	public static void main(String[] args) {
		
		Factorial f = new Factorial();
		System.out.println(f.getFactorial(5));
		System.out.println(f.getFactorialWhile(5));
		System.out.println(f.getFactorialFor(5));
	}

	public int getFactorialFor(int n) {
		int fact=1;
		for (int i = 1; i<=n; i++) {
			fact=fact*i;
		}
		return fact;
	}

	private int getFactorialWhile(int n) {
		int fact=1;
		while(n>0) {
			fact = fact*n;
			n--;
		}
		return fact;
	}

	private int getFactorial(int n) {
		if(n==1) return 1;
		else return n*getFactorial(n-1);
	}
}
