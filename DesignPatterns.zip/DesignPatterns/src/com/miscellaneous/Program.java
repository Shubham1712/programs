package com.miscellaneous;

class A {

	protected void show() {
		String str1 = "ABCD";
		String str2 = "ABCDBABEDCDCBD";
		System.out.println("This is show");
		for (int i = 0; i < str2.length(); i++) {
			System.out.println(i+" "+str2.charAt(i)+" "+str1.indexOf(str2.charAt(i)));
		}
	}
}

public class Program extends A{
	public static void main(String[] args) {
		Program p = new Program();
		p.show();
	}
}
