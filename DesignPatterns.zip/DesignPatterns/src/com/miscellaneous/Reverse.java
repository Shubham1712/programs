package com.miscellaneous;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Reverse {

	public static void main(String[] args) {
		System.out.println("Original No. - 1234565 Reverse No. -"+Reverse.reverseNo(1234565));
		System.out.println("Original String - 'Hello World' Reverse String - '"+Reverse.reverseString("Hello World")+"'");
		List<Integer> arrList = new ArrayList<Integer>();
		arrList.add(1);
		arrList.add(2);
		arrList.add(3);
		arrList.add(4);
		arrList.add(5);
		arrList.add(6);
		System.out.println("Original List:"+arrList+" Reverse list :"+getReverseList(arrList));
		Collections.sort(arrList);
		System.out.println("Collections.sort :"+arrList);
		
	}

	private static List<Integer> getReverseList(List<Integer> arrList) {
		for (int i = 0; i < arrList.size()/2; i++) {
			int temp = arrList.get(i);
			arrList.set(i, arrList.get(arrList.size()- i- 1));
			arrList.set(arrList.size()- i- 1, temp);
		}
		return arrList;
	}

	private static String reverseString(String string) {
		StringBuilder result = new StringBuilder();
		for(int i=string.length()-1; i>=0 ; i--) {
			result.append(string.charAt(i));
		}
		return result.toString();
	}

	private static int reverseNo(int n) {
		int remainder = 0;
		int reverse = 0;
		while(n>0) {
			remainder = n%10;
			reverse = reverse*10 + remainder;
			n = n/10;
		}
		return reverse;
	}
}
