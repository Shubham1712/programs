package com.miscellaneous;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StringTestProgram1 {

	public static void main(String[] args) {

		StringTestProgram1 program = new StringTestProgram1();
		String[] array = { "ADBCBACDB", "ABDCZDA", "ABCDBCBCDA", "ADBCDBCAA", "ABCDEADABAB", "ABCDBABEDCDCBDD" };

		String result = program.getLongestString("ABCD", array);
		System.out.println("Result -" + result);
	}

	private String getLongestString(String valid, String[] array) {

		String result = "";
		int match = 0;
		int nonmatch = 0;
		List<String> strList1 = new ArrayList<>();
		for (String str : array) {
			nonmatch = 0;
			for (int i = 0; i < str.length() - 1; i++) {
				if (str.charAt(i) == str.charAt(i + 1)) {		//Checking repeatative character
					nonmatch++;
				}
			}
			if (nonmatch == 0) {
				match = 0;
				nonmatch = 0;
				for (int i = 0; i < str.length(); i++) {
					if (valid.indexOf(str.charAt(i)) >= 0) {	//Checking occurence of character of input string into array string
						match++;
					} else
						nonmatch++;
				}
				if (match >= valid.length() && nonmatch == 0)	//if all charater are matching, creating new list
					strList1.add(str);
			}
		}
		if (!strList1.isEmpty()) {
			result = Collections.max(strList1, Comparator.comparing(String::length));	//Fetching mas from array of list
		} else {	
			result = "No match found";
		}
		return result;
	}
}
