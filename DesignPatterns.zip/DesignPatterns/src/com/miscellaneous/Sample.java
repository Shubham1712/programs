package com.miscellaneous;

public class Sample {

	String s1 = "cat";
	String s2 = "cat";
	String str = new String("cat");
	String str1 = new String("cat");
	
	public static void main(String[] args) {
		
		Sample sample = new Sample();
		System.out.println(sample.s1.equals(sample.s2));
		System.out.println(sample.s1==(sample.str));
		System.out.println(sample.str.equals(sample.str1));
		System.out.println(Integer.parseInt("12333"));
	}
}
