package com.miscellaneous;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Employee {

	private int id;
	private int age;
	private String name;
	
	public Employee() {
	}
	
	public Employee(int id, int age, String name) {
		super();
		this.id = id;
		this.age = age;
		this.name = name;
	}

	@Override
	public String toString() {
		return "empName "+name;
	}

	public static void main(String[] args) {
		List<Employee> emplist = new ArrayList<>();
		Employee emp = new Employee();
		emplist.add(new Employee(1, 34, "S"));
		emplist.add(new Employee(2, 40, "R"));
		emplist.add(new Employee(3, 45, "G"));
		emplist.add(new Employee(4, 50, "T"));
		
		//emplist.stream().filter(emp -> emp.age > 40).forEach(p -> System.out.println(p));
		
		//emplist.stream().filter(emp1 -> emp1.getAge() > 40).collect(Collectors.toList());
		List<Employee> emplist1 = emplist.stream().filter(emp1 -> emp1.age > 40).collect(Collectors.toList());
		
		emplist1.stream().forEach(r -> System.out.println(r));
	}
}