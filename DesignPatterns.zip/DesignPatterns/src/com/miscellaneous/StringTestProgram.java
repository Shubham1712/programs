package com.miscellaneous;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StringTestProgram {
	
	public static void main(String[] args) {
		
		StringTestProgram program = new StringTestProgram();
		String[] array = {"ADBADB","ABDCDA", "ABCDDBCDAZ", "ADBCDBCAA", "ABBCDEADD", "ABCDBABDCDCBDD"};
		
		String result = program.getLongestString("ABCD", array);
		System.out.println("Result -"+result);
	}

	private String getLongestString(String valid, String[] array) {
		
		String result="";
		int match=0;
		int nonmatch=0;
		int watch=0;
		List<String> strList = new ArrayList<>();
		for (String str : array) {
			match=0;
			nonmatch=0;
			for(int i=0; i< str.length()-1; i++) {
				if(str.charAt(i)==str.charAt(i+1)) {
					nonmatch++;
				}
				else {
					watch=0;
					for(int j=0;j<valid.length();j++) {
						if(valid.charAt(j)==str.charAt(i)) {
							match++;
							watch++;
						}
					}
					if(watch==0) break;
				}
			}
			if(match>valid.length() && nonmatch==0) {
				strList.add(str);
			}
		}
		if(!strList.isEmpty()) {
			int index=0;
			int largest = strList.get(0).length();
			for(int i=1; i<strList.size();i++) {
				if(strList.get(i).length() > largest) {
					largest = strList.get(i).length();
					index=i;
				}
			}
			System.out.println("Result0 - "+strList.get(index));
			result = Collections.max(strList, Comparator.comparing(String::length));
		}
		return result;
		
	}
}
