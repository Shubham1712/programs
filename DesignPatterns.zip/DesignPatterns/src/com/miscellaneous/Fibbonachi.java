package com.miscellaneous;

public class Fibbonachi {

	public static void main(String[] args) {
		
		Fibbonachi f = new Fibbonachi();
		System.out.println(f.getSeriesIndexNumber(5));
		f.printSeries(8);
	}

	private void printSeries(int n) {
		int i=0; int j=1; int m;
		System.out.print("Series - "+i+" "+j);
		for(int k=2; k<=n; k++) {
			m=i+j;
			System.out.print(" "+m);
			i=j;
			j=m;
		}
	}

	private int getSeriesIndexNumber(int n) {
		if(n==0 || n == 1) return 1;
		else return getSeriesIndexNumber(n-1) + getSeriesIndexNumber(n-2);
	}
}

//0 1 1 2 3 5