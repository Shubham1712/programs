package com.java8;

class Animal{
	
	public void test() {
		System.out.println("Animal - test");
	}
}

public class DownCasting extends Animal{

	
	public void test() {
		System.out.println("DownCasting - test");
	}
	
	public static void main(String[] args) {
		Animal a = new DownCasting();
		//DownCasting d = (DownCasting) new Animal();
		a.test();
	}
}
