package com.java8;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

/**
 *	javac -parameters MethodParameterReflec.java  
 *
 */
public class MethodParameterReflec {
	
	public void show(String str) {
		System.out.println("HI "+str);
	}
	
	public static void staticShow(int a) {
		System.out.println("Int - "+a);
	}
	
	public int add(int a, int b) {
		return a+b;
	}
	

	public static void main(String[] args) {
		
		MethodParameterReflec reflec = new MethodParameterReflec();
		reflec.show("Shubham");
		MethodParameterReflec.staticShow(4);
		
		Method[] method = reflec.getClass().getDeclaredMethods();
		
		for (Method method2 : method) {
			
			System.out.println("Method name :"+method2.getName());
			
			Parameter[] parameters = method2.getParameters();
			
			for (Parameter parameter : parameters) {
				
				System.out.print("Method params type- "+parameter.getParameterizedType());
				System.out.print(" Method params name- "+parameter.getName());
			}
			 System.out.println();  
		}
	}
}
