package com.java8;

import com.java8.interfaces.Interface1;
import com.java8.interfaces.Interface2;

public class Class1 implements Interface1, Interface2{

	public static void main(String[] args) {
		Interface1 cls = new Class1();
		cls.test();
		cls.defaultShow();
		cls.defaultShow1();
		Interface1.staticShow();
		Interface2.staticShow();
		cls.defaultShow();
		Class1.staticShow();
		
	}

	@Override
	public void test() {
		System.out.println("Test method");
		
	}


	@Override
	public void defaultShow() {
		Interface2.super.defaultShow();
	}

	static void staticShow() {
		System.out.println("Class1 static show method");
	}

}
