package com.java8;


interface Place{
	 void getMessage(String str);
	//OR ConstructorReference getMessage(String str);
}

public class ConstructorReference {

	public ConstructorReference(String str) {
		System.out.println("In Constructor "+str);
	}
	
	public static void main(String[] args) {
		
		Place place =  ConstructorReference::new;
		place.getMessage("Constructor Reference");
	}
}
