package com.java8;

import java.util.StringJoiner;

public class StringJoinerExample {  
    public static void main(String[] args) {  
        StringJoiner joinNames = new StringJoiner(","); // passing comma(,) as delimiter   
        //StringJoiner joinNames = new StringJoiner(",", "[", "]");   // passing comma(,) and square
        var d = 3;
        System.out.println(joinNames.hashCode());
        // Adding values to StringJoiner  
        joinNames.add("Rahul");  
        joinNames.add("Raju");  
        joinNames.add("Peter");  
        joinNames.add("Raheem");  
                  
        System.out.println(joinNames);  
        
        String meeting = "safds";
        System.out.println(meeting.startsWith("s"));
        
    }  
}  