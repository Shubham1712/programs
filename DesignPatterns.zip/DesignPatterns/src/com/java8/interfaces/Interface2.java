package com.java8.interfaces;

public interface Interface2 {

	void test();
	static void staticShow() {
		System.out.println("Interface2 show method");
	}
	default void defaultShow() {
		System.out.println("Interface2 show method");
	}
}
