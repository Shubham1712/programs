package com.java8.interfaces;

public interface Interface1 {

	void test();
	static void staticShow() {
		System.out.println("Interface1 show method");
	}
	default void defaultShow() {
		System.out.println("Interface1 show method");
	}
	
	default void defaultShow1() {
		System.out.println("Interface1 show method-1");
	}
}
