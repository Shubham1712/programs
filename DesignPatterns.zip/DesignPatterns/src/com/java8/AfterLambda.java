package com.java8;

interface Drawable {
	void draw(int a);
}

public class AfterLambda {

	public static void main(String[] args) {
		
		Drawable shape = i -> System.out.println("After Lambda "+i);			
		shape.draw(5);
		
		Drawable shape1 = i -> System.out.println("After Lambda "+i);			
		shape1.draw(8);
	}
	
}
