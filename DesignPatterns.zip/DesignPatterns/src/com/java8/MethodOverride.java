package com.java8;

class Method{
	
	public static void test() {
		System.out.println("Method - test");
	}
	
}


public class MethodOverride extends Method{

	public static void test() {
		System.out.println("MethodOverride - test");
	}
	
	public static void main(String[] args) {
		MethodOverride m = new MethodOverride();
		m.test();
	}
}
