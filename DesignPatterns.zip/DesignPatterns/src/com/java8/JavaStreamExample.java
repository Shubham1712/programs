package com.java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Product {
	private final int id;
	String name;
	Float price;

	public Product(int id, String name, float price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
}

public class JavaStreamExample {
	public static void main(String[] args) {
		List<Product> productsList = new ArrayList<Product>();
		// Adding Products
		productsList.add(new Product(1, "HP Laptop", 25000f));
		productsList.add(new Product(2, "Dell Laptop", 30000f));
		productsList.add(new Product(3, "Lenevo Laptop", 28000f));
		productsList.add(new Product(4, "Sony Laptop", 28000f));
		productsList.add(new Product(5, "Apple Laptop", 90000f));
		// This is more compact approach for filtering data
		productsList.stream().filter(p -> p.price > 29000).forEach(p -> System.out.println(p.name));
		productsList.stream().filter(p -> p.name.startsWith("D")).forEach(p -> System.out.println(p.name));
		HashMap<String, Integer> map = new HashMap<>();
		// Add elements to the map
		map.put("vishal", 10);
		map.put("sachin", 30);
		map.put("vaibhav", 20);	
		
		List<Integer> arrList = map.values().parallelStream().collect(Collectors.toCollection(ArrayList::new));
		System.out.println(arrList);
		
		//min price
		System.out.println("Max product price - "+productsList.stream().max((p1, p2) -> p1.price>p2.price ? 1 : -1).get().name);
	
		//Converting list to map
		Map<String, Float> mapNew = productsList.stream().collect(Collectors.toMap(p->p.name, p->p.price));
		System.out.println(mapNew);
		
		Iterator<Product> itr = productsList.iterator();
		
		while (itr.hasNext()) {
			Product product = itr.next();
			System.out.println(product);
		}
	}
}






