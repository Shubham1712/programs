package com.java8;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Exception {

	public static void main(String[] args) {
		
		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream("file");
		}  catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException");
			e.printStackTrace();
		}catch (IOException e) {
			System.out.println("IOException");
			e.printStackTrace();
		} 
		DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
	}
}
