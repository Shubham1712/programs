package com.java8;

class A{
	
	final void show() {
		System.out.println("A show");
	}
}

public class JavaInheritance extends A{

	
	public static void main(String[] args) {
		A a= new JavaInheritance();
		a.show();
	}
}
