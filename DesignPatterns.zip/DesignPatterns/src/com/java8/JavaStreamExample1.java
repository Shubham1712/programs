package com.java8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.stream.Stream;

public class JavaStreamExample1 {

	public static void main(String[] args) {

		LinkedList<Integer> m = new LinkedList<>();
		Stream<Integer> numbers3 = Stream.of(1, 2, 3, 4, 5);
		System.out.println("Stream contains 4? " + numbers3.anyMatch(i -> i == 41));
		// Stream contains 4? true

		Stream<Integer> numbers4 = Stream.of(1, 2, 3, 4, 5);
		System.out.println("Stream contains all elements less than 10? " + numbers4.allMatch(i -> i < 101));
		// Stream contains all elements less than 10? true

		Stream<Integer> numbers5 = Stream.of(1, 2, 3, 4, 5);
		System.out.println("Stream doesn't contain 10? " + numbers5.noneMatch(i -> i == 110));
		// Stream doesn't contain 10? true

		ArrayList<Integer> al = new ArrayList<>();
		al.add(3);
		al.add(2);
		al.add(1);
		al.add(5);
		al.add(6);
		
		System.out.println("List - "+al);

		Iterator iter1 = al.iterator();
		while (iter1.hasNext()) {
			System.out.println(iter1.next());
		}
	}
}
