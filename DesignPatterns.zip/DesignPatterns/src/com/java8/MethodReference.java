package com.java8;

@FunctionalInterface
interface Sayable{
	void say(String s);
	default void test() {}
	static void testStatic() {}
}

public class MethodReference {
	
	public static void saySomething(String str) {
		System.out.println("Hi, You are in static method of "+str+" class");
	}
	
	public void nonStaticSaySomething(String str) {
		System.out.println("Hi, You are in non static method of "+str+" class");
	}

	public static void main(String[] args) {
		
		Sayable say =  MethodReference::saySomething;
		say.say("Static Method Reference");
		//MethodReference methodReference = new MethodReference();
		//say = methodReference::nonStaticSaySomething;
		say = new MethodReference()::nonStaticSaySomething;
		say.say("Non Static Method Reference");
		
	}
}
