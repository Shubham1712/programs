package com.java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jdk.jfr.Enabled;

interface Shape {
	void draw();
}
public class BeforeLambda {

	static Map<String,Integer> map = new HashMap<>();
	static List<Integer> list = new ArrayList<>();
	
	public void test() {
		map.put("w3r3", 1);
		String name = "4543";
		System.out.println(Integer.valueOf(name)%10);
	}
		
	public static void main(String[] args) {
		
		BeforeLambda b = new BeforeLambda();
		b.test();
	
		Shape shape = new Shape() {
			
			@Override
			public void draw() {
				 System.out.println("Before Lambda");			
			}
		};
		shape.draw();
	}
	
}
