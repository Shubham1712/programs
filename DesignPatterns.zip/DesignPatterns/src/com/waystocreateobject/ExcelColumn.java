package com.waystocreateobject;

import java.util.Scanner;

public class ExcelColumn {

	public static void main(String[] args) {

		String input = "";
		System.out.println("Enter input :");
		Scanner scan = new Scanner(System.in);
		input=scan.next();
		scan.close();
		
		int output = getColumnNumber(input);
		System.out.println("Column - "+input+" Value - "+output);
	}

	private static int getColumnNumber(String input) {
		int column=0;
		if(input.length()==1)
			return getValue(input);
		else {
			for(int i=0;i<input.length();i++) {
				if(i==input.length()-1)
					column+=getValue(input);
			}
		}
		return 0;
	}

	private static int getValue(String input) {
		if(input.equals("a"))
			return 1;
		
		return 0;
	}

}

// a b c d		aa ab ac ad 		ba bb bc bd		da db dc  dd.......za zb zz.	aaa aab aac	aad