package com.waystocreateobject;

import java.util.ArrayList;
import java.util.List;

public class TestProgram {
	
	public static void main(String[] args) {
		
		int a[]= {-1,0,1,0,0,0,-2,-2,4,2};
		List<List<Integer>> result = process(a, a.length);
		System.out.println("Result -"+result);
	}

	private static List<List<Integer>> process(int[] a, int length) {
		int sum=0;
		List<List<Integer>> resultList = new ArrayList<>();
		for (int i = 0; i < length-1; i++) {		//n-1 * n-1 n^2 =O(n^2)
			for(int j=i+1;j<length-1;j++) {
				sum=a[i]+a[j]+a[j+1];
				
				
				
				
				//System.out.println(""+a[i]+"    "+a[j]+"   "+a[j+1]);
				if(sum==0 && !resultList.contains(List.of(a[i],a[j],a[j+1])) && !resultList.contains(List.of(a[j],a[i],a[j+1])) 
						&& !resultList.contains(List.of(a[j+1],a[j],a[i]))) {
						resultList.add(List.of(a[i],a[j],a[j+1]));
				}
			}
		}
		
		return resultList;
	}

}
//Given -int array -ve +posit 0 repeated numbers allowed
//All the triplets whose sum is 0, triplets should be unique


//ad 30 31  a b c d aa ab ac ad  ba bb bc bd  .............za zb  	aa bb cc dd 

