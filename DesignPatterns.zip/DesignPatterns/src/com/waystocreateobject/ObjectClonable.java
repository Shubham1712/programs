package com.waystocreateobject;

public class ObjectClonable implements Cloneable{
	
	
	private String nam = "CLONE";
	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public static void main(String[] args) throws CloneNotSupportedException {
		
		ObjectClonable obj = new ObjectClonable();
		
		
		ObjectClonable obj1 = (ObjectClonable) obj.clone();
		
		System.out.println("obj - "+obj.nam);
		System.out.println("obj1 - "+obj1.nam);
	}
}
