package com.waystocreateobject;

public class Object1 {

	
	public void test() {
		System.out.println("Success");
	}
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		
		Object1 obj = Object1.class.newInstance();
		obj.test();
	}
}
