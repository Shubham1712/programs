package com.waystocreateobject;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Object2 {

	public void test() {
		System.out.println("Success");
	}
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		
		Constructor<Object2> obj = Object2.class.getConstructor();
		Object2 obj2 = obj.newInstance();
		obj2.test();
		
		Object2 obj1 = Object2.class.getConstructor().newInstance();
		obj1.test();
	}
}
