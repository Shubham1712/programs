package com.behaviral.observer;

import java.util.ArrayList;
import java.util.List;

public class ObserverPattern {

	static class CenturyNotifier{
		
		List<SachinFan> fans = new ArrayList<>();
		
		public void register(SachinFan sachinFan) {
			fans.add(sachinFan);
		}
		
		public void sachinScoredACentury() {
			fans.stream().forEach(fan -> fan.announce());
		}

		
		 	
	}
	static class SachinFan{
		private String name;
		public SachinFan(String name) {
			this.name=name;
		}
		
		public void announce() {
			System.out.println(name+" notified");
		}
	}
	
	public static void main(String[] args) {
		CenturyNotifier notifier = new CenturyNotifier();
		notifier.register(new SachinFan("Gaurav"));
		notifier.register(new SachinFan("Yogesh"));
		notifier.register(new SachinFan("Rode"));
		notifier.sachinScoredACentury();
	}
}
