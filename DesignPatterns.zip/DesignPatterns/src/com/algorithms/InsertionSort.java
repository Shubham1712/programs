package com.algorithms;

import java.util.Arrays;

public class InsertionSort {

	public static void main(String[] args) {
		
		  int[] a = {10, 9, 7, 101, 23, 44, 12, 78, 34, 23};  
		  
			/*
			 * for (int k = 1; k < a.length; k++) {
			 * 
			 * int temp = a[k]; int j=k-1; while(j>=0 && temp<=a[j]) { a[j+1]=a[j]; j--; }
			 * a[j+1]=temp; }
			 */
		  
		  for (int i = 1; i < a.length; i++) {
			
			  int hole = i;
			  int value = a[i];
			  while(hole>0 && a[hole-1]>value) {
				  a[hole]=a[hole-1];
				  hole=hole-1;
			  }
			  a[hole]=value;
		}
		  System.out.println("Sorted array -"+Arrays.toString(a));
	}
}
