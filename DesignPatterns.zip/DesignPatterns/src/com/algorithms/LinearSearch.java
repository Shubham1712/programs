package com.algorithms;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		
		int element;
		int flag=0;
		int[] arr= {4,6,3,7,9,8};
		System.out.println("Enter element to search:");
		Scanner scan = new Scanner(System.in);
		element = scan.nextInt();
		
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]==element) {
				flag++;
				break;
			}else
				flag=0;
		}
		if(flag!=0)
			System.out.println("Found");
		else
			System.out.println("Not found");
	}
}
