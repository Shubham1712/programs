package com.algorithms;

public class Newton {

	public static void main(String[] args) {
		
		int result = 349651;
		//newton 	add 
		
		while(result>10) {
			result = funct(result);
		}
		if(result==9)
			System.out.println("Newton");
		else 
			System.out.println("not newton");

	}//grid  

	private static int funct(int i) {
		int result=0;
		if(i<10)
			return i;
		else {
			while(i>0) {
				int rem = i%10;			//5	4	3
				result = result + rem;
				i = i/10;				//1234		123
			}
		}
		return result;
	}

}
