package com.algorithms;

import java.util.Arrays;

public class BinarySearch {

	public static void main(String[] args) {
		
		BinarySearch binarySearch = new BinarySearch();
		int[] arr= {4,6,3,7,9,8};
		int search = 6;
		Arrays.sort(arr);
		System.out.println("Sorted array - "+Arrays.toString(arr));
		int location = binarySearch.isValuePresent(arr, 0, arr.length-1, search);
		if(location != -1)
				System.out.println("Is present - true and location - "+location);
		else
			System.out.println("Is present - false");
	}

	private int isValuePresent(int[] arr, int beg, int end, int search) {
		
		int mid;
		if(end>=beg) {
			mid = (beg+end)/2;
			if(arr[mid]==search) {
				return mid+1;
			}
			else if(arr[mid]>search) {
				return isValuePresent(arr, beg, mid-1, search);
			}
			else {
				return isValuePresent(arr, mid+1, end, search);
			}
			
		}
		return -1;
	}
}
