package com.algorithms;

import java.util.Arrays;

public class SelectionSort {

	public static void main(String[] args) {
		
		int[] a= {23,67,98,45,67,34,88,99,54};
		SelectionSort sort = new SelectionSort();
		sort.sortArray(a);
		System.out.println("Sorted array -"+Arrays.toString(a));
		
	}

	private void sortArray(int[] a) {
		for (int i = 0; i < a.length-1; i++) {
			int min=i;
			for (int j = i+1; j < a.length; j++) {
				
				if(a[j]<a[min]) {
					min=j;
				}
				int temp = a[i];
				a[i]=a[min];
				a[min]=temp;
			}
			
		}
		
	}
}
