package com.algorithms;

import java.util.Arrays;

public class BubbleSort {

	public static void main(String[] args) {
		
		int arr[] = {34,6,3,77,47,95,4,86,19};
		int length=arr.length;
		int temp;
		System.out.println("Unsorted arrray :"+Arrays.toString(arr));
		for (int i = 0; i < length; i++) {
			
			for (int j = 0; j < length; j++) {
				
				if(arr[i]<arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		System.out.println("Sorted arrray :"+Arrays.toString(arr));
	}
}
