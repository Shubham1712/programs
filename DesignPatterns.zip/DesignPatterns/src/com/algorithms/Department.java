package com.algorithms;

public class Department {
	
	int deptId;
	String deptName;
	public Department(int deptId, String deptName) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
	}
	

}
