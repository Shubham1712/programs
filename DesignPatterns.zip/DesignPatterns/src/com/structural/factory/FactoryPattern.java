package com.structural.factory;

public class FactoryPattern {
	
	public static void main(String[] args) {
		Person male = PersonFactory.getPerson("Shubham", "M");
		System.out.println("Male - "+male.getNameAndSalutation());
		
		Person female = PersonFactory.getPerson("Neha", "F");
		System.out.println("Female - "+female.getNameAndSalutation());
	}
}
