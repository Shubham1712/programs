package com.structural.factory;

public class Female extends Person{

	
	public Female(String name) {
		super(name);
	}
	
	@Override
	public String getSalutation() {
		return "Mrs";
	}

}
