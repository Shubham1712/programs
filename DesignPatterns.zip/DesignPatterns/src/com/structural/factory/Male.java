package com.structural.factory;


public class Male extends Person{

	
	public Male(String name) {
		super(name);
	}
	
	@Override
	public String getSalutation() {
		return "Mr";
		
	}
	
}
