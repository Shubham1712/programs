package com.structural.factory;

public class PersonFactory {

	private PersonFactory() {
	}
	
	public static Person getPerson(String name, String type) {
		
		if(type.equalsIgnoreCase("M")) {
			return new Male(name);
		}else if(type.equalsIgnoreCase("F")) {
			return new Female(name);
		} else
			return null;
	}

	
}
