package com.structural.factory;

public abstract class Person {

	private String name;
	
	public Person(String name) {
		this.name=name;
	}
	
	abstract String getSalutation();
	
	public String getNameAndSalutation(){
		return getSalutation()+" "+name;
	}
	
}
