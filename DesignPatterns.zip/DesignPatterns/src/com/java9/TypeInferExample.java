package com.java9;

abstract class ABCD<T>{  
    abstract T show(T a, T b);  
}  
public class TypeInferExample implements Cloneable{  
    public static void main(String[] args) {  
        ABCD<String> a = new ABCD<>() { // diamond operator is empty  
            String show(String a, String b) {  
                return a+b;   
            }  
        };    
        var result = a.show("Java","9");  
        System.out.println(result);  
    }  
    
    void getClone() throws CloneNotSupportedException {
    	super.clone();
    }
}  