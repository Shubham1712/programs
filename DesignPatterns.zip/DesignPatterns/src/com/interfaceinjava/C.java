package com.interfaceinjava;

public class C extends B{

	static final int r = 0;
	
	public C() {
		super(1);
		
	}
	
	@Override
	public void print() {
		System.out.println("print method in C");
	}
	
	
	public void test() {
		System.out.println("No parameters");
	}
	
	public int test(int i) {
		return i;
	}
	
	public static void main(String[] args) {
		C c = new C();		////upcasting  
		B b = new C();
		b.print();
		c.test();
		c.finalMethod();
		System.out.println(c.test(4));
	}
}
