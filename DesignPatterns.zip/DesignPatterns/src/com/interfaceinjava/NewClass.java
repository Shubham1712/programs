package com.interfaceinjava;

public class NewClass {

	 public static class Superclass { 
	        static void print() 
	        { 
	            System.out.println("print in superclass."); 
	        } 
	    } 
	    public static class Subclass extends Superclass { 
	        static void print() 
	        { 
	            System.out.println("print in subclass."); 
	        } 
	    } 
	  
	    public static void main(String[] args) 
	    { 
	    	Superclass A = new Superclass(); 
	    	Superclass B = new Subclass(); 
	        A.print(); 
	        B.print(); 
	    } 
}
