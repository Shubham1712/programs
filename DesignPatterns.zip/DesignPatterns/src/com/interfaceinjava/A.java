package com.interfaceinjava;

public interface A {

	int p = 2;
	void print();
	default void defaultMethod() {
		System.out.println("This is default method");
	}
	static void statidMethod() {
		System.out.println("This is static method");
	}
}
