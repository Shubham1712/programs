package com.interfaceinjava;

public class B implements A{

	public static void main(String[] args) {
		A a = new B();		
		a.print();
		a.defaultMethod();
		A.statidMethod();
		System.out.println("p - "+A.p);
	}
	
	public B(int i) {
		System.out.println("Constructor - "+i);
	}
	
	public B() {
		this(1);
	}

	@Override
	public void print() {
		System.out.println("Overrided method");
	}

	public final void finalMethod() {
		System.out.println("Final method in B");
	}
}
