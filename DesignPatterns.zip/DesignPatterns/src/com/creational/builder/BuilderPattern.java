package com.creational.builder;

public class BuilderPattern {
	
	static class Bike{
		
		private String type;
		private Boolean cellStart;
		private Boolean sports;
		private String weight;
		
		 public Bike(Builder builder) {
			this.type=builder.type;
			this.cellStart=builder.cellStart;
			this.sports=builder.sports;
			this.weight=builder.weight;
		}

		static class Builder{
			 
			 	private String type;
				private Boolean cellStart;
				private Boolean sports;
				private String weight;
				
				public Builder(String type) {
					this.type=type;
				}
				public Builder cellStart(Boolean value) {
					this.cellStart=value;
					return this;
				}
				public Builder sports(Boolean value) {
					this.sports=value;
					return this;
				}
				public Builder weight(String value) {
					this.weight=value;
					return this;
				}
				
				public Bike build() {
					return new Bike(this);
				}
				
		 }

		@Override
		public String toString() {
			return "Bike [type=" + type + ", cellStart=" + cellStart + ", sports=" + sports + ", weight=" + weight
					+ "]";
		}
	}
	
	public static void main(String[] args) {
		
		Bike bike = new Bike.Builder("bike").cellStart(true).sports(false).weight("100kg").build();
		System.out.println("Bike1 - "+bike);
		
		Bike bike1 = new Bike.Builder("Bike").cellStart(false).weight("120kg").build();
		System.out.println("Bike2 - "+bike1);
	}
	
}
