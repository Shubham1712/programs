package com.thread;

/**
 * @author ST52015
 *
 */
/**
 * @author ST52015
 *
 */
public class RunnableThread implements Runnable{

	@Override
	public void run() {
		System.out.println("Current thread "+Thread.currentThread());
		
	}
	
	public static void main(String[] args) {
		RunnableThread runnableThread = new RunnableThread();
		Thread t1 = new Thread(runnableThread);
		t1.start();
		
	}
}
