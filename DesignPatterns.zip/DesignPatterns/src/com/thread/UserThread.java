package com.thread;

public class UserThread extends Thread{

	@Override
	public void run() {
		System.out.println("Thread is running...");
	}
	
	public static void main(String[] args) {
		UserThread t1 = new UserThread();
		
		t1.start();
		t1.start();
		
		System.out.println("Thrad name - "+t1.getName());
	}
	
}
